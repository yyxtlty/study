
/**
 * <p>This package contains the classes related to maintaining the
 * persistence of the Tickets for retrieval later by the Central
 * Authentication Service.</p>
 * @since 3.0
 */
package org.jasig.cas.ticket.registry;
