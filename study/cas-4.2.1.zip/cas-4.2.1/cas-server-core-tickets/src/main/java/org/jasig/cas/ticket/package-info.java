/**
 * Classes that represent tickets and can manipulate tickets.
 * @since 3.0
 */

package org.jasig.cas.ticket;

