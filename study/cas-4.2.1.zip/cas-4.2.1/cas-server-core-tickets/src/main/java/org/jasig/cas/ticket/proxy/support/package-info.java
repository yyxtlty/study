/**
 * <p>Package containing the specific implementations of the ProxyHandler
 * interface related to the various versions of the CAS protocol.</p>
 * @since 3.0
 */
package org.jasig.cas.ticket.proxy.support;

